/**
 * Google Sheets Sync Configuration
 * 
 * IMPORTANT: This file contains your credentials.
 * Never commit this file to version control!
 * 
 * How to get your credentials:
 * 1. Go to https://console.cloud.google.com/
 * 2. Go to APIs & Services > Credentials
 * 3. Copy your Client ID and API Key
 * 4. Paste them below in the config file
 */

const GOOGLE_CONFIG = {
    // Replace with your actual Client ID from Google Cloud Console
    CLIENT_ID: '333263441804-uu487tnl7bisdlk1gmmetla51t95m4uf.apps.googleusercontent.com',
    
    // Replace with your actual API Key from Google Cloud Console
    API_KEY: 'AIzaSyCPml2zhIkBqtgNgXKbA9HS1zjMtJViwkI',
    
    // These should not be changed
    SCOPES: ['https://www.googleapis.com/auth/spreadsheets'],
    DISCOVERY_DOCS: ['https://sheets.googleapis.com/$discovery/rest?version=v4'],
};
